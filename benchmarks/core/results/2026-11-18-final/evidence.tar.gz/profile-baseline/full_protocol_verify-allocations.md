# full_protocol_verify-allocations

# calls=155 requested_bytes=17338; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::raw::scan (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:147)` | 31 | 3012 |
| `nazo_mdoc::verifier::verify_presentation (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/verifier.rs:68)` | 1 | 1696 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:285)` | 11 | 1408 |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 5 | 1400 |
| `<x509_cert::name::RelativeDistinguishedName as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 4 | 1152 |
| `nazo_mdoc::parser::parse_with_limits (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:55)` | 1 | 1064 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:?)` | 4 | 570 |
| `<ciborium::value::Value as core::convert::From<&[u8]>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 5 | 544 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:530)` | 2 | 499 |
| `<nazo_mdoc::model::issuer_auth::IssuerAuth>::certificate_chain_der (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_auth.rs:65)` | 2 | 440 |
| `nazo_mdoc::parser::parse_cose (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:290)` | 1 | 391 |
| `<x509_cert::certificate::TbsCertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:117)` | 3 | 361 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_auth.rs:239)` | 1 | 308 |
| `nazo_mdoc::cose::validate_headers (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/mod.rs:84)` | 1 | 280 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/rustc/0ef1bc386059596dada8fb65b50425aab2ea637a/library/alloc/src/collections/btree/set.rs:?)` | 1 | 280 |
| `<coset::header::Header as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:196)` | 1 | 256 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:529)` | 2 | 256 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:276)` | 1 | 256 |
| `nazo_mdoc::parser::parse_issuer_signed (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:146)` | 2 | 229 |
| `nazo_mdoc::parser::parse_issuer_signed (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:142)` | 1 | 224 |
| `<ciborium::value::Value as core::convert::From<&str>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 18 | 217 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:216)` | 2 | 217 |
| `nazo_mdoc::cose::verify::validate_verification_key (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/verify.rs:64)` | 2 | 208 |
| `<x509_cert::name::RdnSequence as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 2 | 192 |
| `<coset::key::CoseKeyBuilder>::new_ec2_pub_key (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:330)` | 1 | 192 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_auth.rs:246)` | 1 | 148 |
| `<coset::key::CoseKey as nazo_mdoc::cose::key::CoseKeyExt>::public_key_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:70)` | 2 | 130 |
| `nazo_mdoc::parser::parse_cose (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:299)` | 2 | 128 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:521)` | 2 | 128 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:203)` | 2 | 120 |
| `nazo_mdoc::disclosure::verify_disclosure (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/disclosure.rs:29)` | 2 | 120 |
| `nazo_mdoc::session::build_device_authentication_validated (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/session.rs:326)` | 1 | 108 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:294)` | 3 | 96 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:206)` | 1 | 84 |
| `nazo_mdoc::disclosure::verify_disclosure (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/disclosure.rs:34)` | 1 | 84 |
| `<x509_cert::certificate::CertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::slice::SliceReader>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:195)` | 1 | 70 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:213)` | 2 | 64 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:13)` | 2 | 64 |
| `nazo_mdoc::cose::key::cose_key_from_spki (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:203)` | 3 | 56 |
| `<x509_cert::ext::Extension as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/ext.rs:27)` | 3 | 51 |
| `<x509_cert::serial_number::SerialNumber as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/serial_number.rs:82)` | 2 | 40 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:179)` | 1 | 32 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:180)` | 1 | 32 |
| `<x509_cert::attr::AttributeTypeAndValue as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/attr.rs:87)` | 4 | 28 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:214)` | 2 | 22 |
| `nazo_mdoc::parser::parse_document (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:79)` | 1 | 21 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:522)` | 2 | 20 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:61)` | 2 | 16 |
| `nazo_mdoc::parser::parse_cose (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:294)` | 2 | 6 |
| `<coset::header::ProtectedHeader as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:360)` | 2 | 6 |
| `nazo_mdoc::device_auth::verify_device_signature (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/device_auth.rs:65)` | 1 | 5 |
| `nazo_mdoc::parser::parse_device_signed (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:228)` | 1 | 4 |
| `nazo_mdoc::parser::parse_with_limits (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:40)` | 1 | 3 |
