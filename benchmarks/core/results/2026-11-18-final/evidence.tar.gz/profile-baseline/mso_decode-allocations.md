# mso_decode-allocations

# calls=59 requested_bytes=4528; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:285)` | 7 | 2112 |
| `nazo_mdoc::cbor::raw::scan (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:147)` | 12 | 1484 |
| `<ciborium::value::Value as core::convert::From<&[u8]>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 19 | 608 |
| `<ciborium::value::Value as core::convert::From<&str>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 18 | 228 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:294)` | 3 | 96 |
