# measurement_control-allocations

# calls=0 requested_bytes=0; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
