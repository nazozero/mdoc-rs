# holder_es256_verify-allocations

# calls=15 requested_bytes=1098; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 1 | 280 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:?)` | 2 | 143 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:529)` | 1 | 128 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:530)` | 1 | 108 |
| `nazo_mdoc::cose::verify::validate_verification_key (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/verify.rs:64)` | 1 | 104 |
| `nazo_mdoc::cbor::raw::scan (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:147)` | 1 | 84 |
| `<coset::key::CoseKey as nazo_mdoc::cose::key::CoseKeyExt>::public_key_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:70)` | 1 | 65 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:285)` | 1 | 64 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:521)` | 1 | 64 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:13)` | 1 | 32 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:522)` | 1 | 10 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:61)` | 1 | 8 |
| `nazo_mdoc::device_auth::verify_device_signature (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/device_auth.rs:65)` | 1 | 5 |
| `<coset::header::ProtectedHeader as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:360)` | 1 | 3 |
