# issuer_es256_verify-allocations

# calls=2 requested_bytes=169; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cose::verify::validate_verification_key (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/verify.rs:64)` | 1 | 104 |
| `<coset::key::CoseKey as nazo_mdoc::cose::key::CoseKeyExt>::public_key_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:70)` | 1 | 65 |
