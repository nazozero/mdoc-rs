# disclosure_verify-allocations

# calls=6 requested_bytes=564; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::disclosure::verify_disclosure (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/disclosure.rs:29)` | 4 | 328 |
| `nazo_mdoc::disclosure::verify_disclosure (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/disclosure.rs:34)` | 2 | 236 |
