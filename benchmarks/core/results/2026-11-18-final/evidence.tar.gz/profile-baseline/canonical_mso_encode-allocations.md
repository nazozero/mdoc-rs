# canonical_mso_encode-allocations

# calls=112 requested_bytes=9575; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::data_item::canonicalize (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/data_item.rs:58)` | 7 | 3168 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:?)` | 15 | 2055 |
| `nazo_mdoc::cbor::data_item::canonicalize (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/data_item.rs:66)` | 3 | 1536 |
| `nazo_mdoc::cbor::raw::scan (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:147)` | 12 | 1484 |
| `<ciborium::value::Value as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:26)` | 19 | 608 |
| `<ciborium::value::Value as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:32)` | 18 | 228 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:36)` | 18 | 144 |
| `<ciborium::ser::CollectionSerializer<&mut alloc::vec::Vec<u8>> as serde_core::ser::SerializeTupleVariant>::serialize_field::<u64> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/ser/mod.rs:416)` | 1 | 128 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:15)` | 12 | 96 |
| `nazo_mdoc::cbor::data_item::canonicalize (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/data_item.rs:87)` | 3 | 96 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:38)` | 3 | 24 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:71)` | 1 | 8 |
