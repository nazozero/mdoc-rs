# issuance_complete-allocations

# calls=254 requested_bytes=19979; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::data_item::canonicalize (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/data_item.rs:58)` | 8 | 2400 |
| `nazo_mdoc::cbor::raw::scan (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:147)` | 20 | 2088 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:?)` | 27 | 1973 |
| `<x509_cert::name::RelativeDistinguishedName as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 4 | 1152 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:387)` | 1 | 640 |
| `nazo_mdoc::cbor::raw::wrap_tag24_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:396)` | 3 | 628 |
| `unresolved` | 4 | 600 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:?)` | 2 | 512 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:530)` | 1 | 391 |
| `nazo_mdoc::cbor::data_item::canonicalize (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/data_item.rs:66)` | 3 | 384 |
| `<x509_cert::certificate::TbsCertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:117)` | 3 | 361 |
| `<ciborium::value::Value as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:32)` | 30 | 343 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:247)` | 2 | 325 |
| `<ciborium::value::Value as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:26)` | 10 | 320 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:15)` | 21 | 320 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:356)` | 1 | 320 |
| `nazo_mdoc::cose::verify::validate_verification_key (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/verify.rs:64)` | 3 | 312 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_auth.rs:239)` | 1 | 308 |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 1 | 280 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/rustc/0ef1bc386059596dada8fb65b50425aab2ea637a/library/alloc/src/collections/btree/set.rs:?)` | 1 | 280 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:81)` | 1 | 256 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:323)` | 1 | 256 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:328)` | 1 | 256 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::to_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:310)` | 1 | 256 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:276)` | 1 | 256 |
| `<coset::sign::CoseSign1Builder>::new (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/util/mod.rs:201)` | 1 | 256 |
| `<coset::header::Header as coset::common::AsCborValue>::to_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:213)` | 1 | 256 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:246)` | 2 | 229 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:198)` | 1 | 224 |
| `nazo_mdoc::builder::fresh_item_randomness (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:412)` | 4 | 216 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace (/cargo/registry/25cdd57fae9f0462/hashbrown-0.17.1/src/raw.rs:?)` | 1 | 212 |
| `<coset::key::CoseKey as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:88)` | 1 | 192 |
| `<x509_cert::name::RdnSequence as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 2 | 192 |
| `<coset::key::CoseKeyBuilder>::new_ec2_pub_key (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:330)` | 1 | 192 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:334)` | 1 | 192 |
| `<coset::key::CoseKey as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:74)` | 1 | 192 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:242)` | 1 | 148 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_auth.rs:246)` | 1 | 148 |
| `<coset::key::CoseKey as nazo_mdoc::cose::key::CoseKeyExt>::public_key_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:70)` | 2 | 130 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:77)` | 1 | 128 |
| `<ciborium::ser::CollectionSerializer<&mut alloc::vec::Vec<u8>> as serde_core::ser::SerializeTupleVariant>::serialize_field::<u64> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/ser/mod.rs:416)` | 1 | 128 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:529)` | 1 | 128 |
| `<nazo_mdoc::time::Timestamp>::format_rfc3339 (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/time.rs:99)` | 3 | 105 |
| `nazo_mdoc::builder::tdate (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:424)` | 3 | 96 |
| `nazo_mdoc::cbor::data_item::canonicalize (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/data_item.rs:87)` | 3 | 96 |
| `<x509_cert::certificate::CertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::slice::SliceReader>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:195)` | 1 | 70 |
| `nazo_mdoc::builder::fresh_item_randomness (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:409)` | 2 | 64 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:217)` | 2 | 64 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:13)` | 3 | 64 |
| `<nazo_mdoc::model::issuer_signed_item::IssuerSignedItem>::compute_digest (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_signed_item.rs:36)` | 2 | 64 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:325)` | 2 | 64 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::to_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:291)` | 1 | 64 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:382)` | 1 | 64 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:521)` | 1 | 64 |
| `nazo_mdoc::cose::key::cose_key_from_spki (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:203)` | 3 | 56 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:202)` | 1 | 52 |
| `<x509_cert::ext::Extension as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/ext.rs:27)` | 3 | 51 |
| `<x509_cert::serial_number::SerialNumber as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/serial_number.rs:82)` | 2 | 40 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:220)` | 2 | 34 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:179)` | 1 | 32 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:180)` | 1 | 32 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:71)` | 4 | 32 |
| `<x509_cert::attr::AttributeTypeAndValue as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/attr.rs:87)` | 4 | 28 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:224)` | 2 | 24 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:38)` | 3 | 24 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace::{closure#0} (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:76)` | 2 | 22 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:221)` | 2 | 22 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:236)` | 2 | 22 |
| `<nazo_mdoc::builder::DocumentBuilder>::new (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:59)` | 1 | 21 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:367)` | 1 | 21 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:79)` | 1 | 17 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:329)` | 1 | 17 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:212)` | 2 | 16 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:362)` | 1 | 15 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:388)` | 1 | 13 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:216)` | 2 | 12 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:370)` | 1 | 12 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:374)` | 1 | 12 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:344)` | 1 | 10 |
| `coset::sign::sig_structure_data (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/sign/mod.rs:522)` | 1 | 10 |
| `<ciborium::value::Value as core::convert::From<&str>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 1 | 9 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:340)` | 1 | 9 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:383)` | 1 | 9 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:36)` | 1 | 8 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:61)` | 1 | 8 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:358)` | 1 | 7 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:363)` | 1 | 7 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:366)` | 1 | 7 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:336)` | 1 | 6 |
| `nazo_mdoc::builder::build_mso_cbor (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/builder.rs:359)` | 1 | 3 |
