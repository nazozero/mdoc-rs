# mso_parse-allocations

# calls=64 requested_bytes=6196; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:285)` | 7 | 2112 |
| `nazo_mdoc::cbor::raw::scan (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:147)` | 12 | 1484 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_auth.rs:246)` | 2 | 824 |
| `<ciborium::value::Value as core::convert::From<&[u8]>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 19 | 608 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/model/issuer_auth.rs:239)` | 1 | 308 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/rustc/0ef1bc386059596dada8fb65b50425aab2ea637a/library/alloc/src/collections/btree/set.rs:?)` | 1 | 280 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:276)` | 1 | 256 |
| `<ciborium::value::Value as core::convert::From<&str>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 18 | 228 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:294)` | 3 | 96 |
