# certificate_key_convert-allocations

# calls=6 requested_bytes=312; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `<coset::key::CoseKeyBuilder>::new_ec2_pub_key (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:330)` | 1 | 192 |
| `nazo_mdoc::cose::key::cose_key_from_spki (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:203)` | 3 | 56 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:179)` | 1 | 32 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cose/key.rs:180)` | 1 | 32 |
