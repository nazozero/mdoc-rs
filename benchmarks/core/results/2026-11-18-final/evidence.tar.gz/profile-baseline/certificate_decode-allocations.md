# certificate_decode-allocations

# calls=22 requested_bytes=2497; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `<x509_cert::name::RelativeDistinguishedName as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 4 | 1152 |
| `<x509_cert::certificate::TbsCertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:117)` | 4 | 937 |
| `<x509_cert::name::RdnSequence as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 2 | 192 |
| `<x509_cert::ext::Extension as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/ext.rs:27)` | 5 | 81 |
| `<x509_cert::certificate::CertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::slice::SliceReader>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:195)` | 1 | 71 |
| `<x509_cert::serial_number::SerialNumber as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/serial_number.rs:82)` | 2 | 40 |
| `<x509_cert::attr::AttributeTypeAndValue as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/attr.rs:87)` | 4 | 24 |
