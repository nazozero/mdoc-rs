# response_parse-allocations

# calls=105 requested_bytes=13114; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::raw::scan (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:147)` | 35 | 3824 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:216)` | 6 | 1842 |
| `<ciborium::value::Value as core::convert::From<&[u8]>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 2 | 1508 |
| `nazo_mdoc::parser::parse_with_limits (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:55)` | 1 | 1064 |
| `nazo_mdoc::parser::parse_cose (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:290)` | 1 | 930 |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 3 | 840 |
| `nazo_mdoc::parser::parse_issuer_signed (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:142)` | 1 | 672 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:285)` | 5 | 576 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:203)` | 4 | 328 |
| `<coset::header::Header as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:196)` | 1 | 256 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:206)` | 2 | 236 |
| `nazo_mdoc::parser::parse_issuer_signed (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:146)` | 2 | 229 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:213)` | 6 | 192 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:294)` | 6 | 192 |
| `<ciborium::value::Value as core::convert::From<&str>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 16 | 158 |
| `nazo_mdoc::parser::parse_cose (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:299)` | 2 | 96 |
| `nazo_mdoc::parser::parse_item (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:214)` | 6 | 73 |
| `<nazo_mdoc::cbor::raw::Item>::value (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/cbor/raw.rs:278)` | 1 | 64 |
| `nazo_mdoc::parser::parse_document (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:79)` | 1 | 21 |
| `nazo_mdoc::parser::parse_cose (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:294)` | 2 | 6 |
| `nazo_mdoc::parser::parse_device_signed (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:228)` | 1 | 4 |
| `nazo_mdoc::parser::parse_with_limits (/home/agent/.cargo/git/checkouts/mdoc-rs-fb7a1085a657c21f/070e9cf/src/parser.rs:40)` | 1 | 3 |
