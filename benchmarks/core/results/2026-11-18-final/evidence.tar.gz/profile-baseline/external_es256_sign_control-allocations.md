# external_es256_sign_control-allocations

# calls=1 requested_bytes=64; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `unresolved` | 1 | 64 |
