# mso_parse-allocations

# calls=64 requested_bytes=6196; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:314)` | 7 | 2112 |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 12 | 1484 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_auth.rs:234)` | 2 | 824 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:295)` | 19 | 608 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_auth.rs:227)` | 1 | 308 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/rustc/0ef1bc386059596dada8fb65b50425aab2ea637a/library/alloc/src/collections/btree/set.rs:?)` | 1 | 280 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:276)` | 1 | 256 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:300)` | 18 | 228 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:320)` | 3 | 96 |
