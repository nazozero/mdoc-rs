# disclosure_verify-allocations

# calls=6 requested_bytes=564; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::disclosure::verify_disclosure (/workspace/scratch/5e92231441b9/mdoc-rs/src/disclosure.rs:25)` | 4 | 328 |
| `nazo_mdoc::disclosure::verify_disclosure (/workspace/scratch/5e92231441b9/mdoc-rs/src/disclosure.rs:30)` | 2 | 236 |
