# mso_decode-allocations

# calls=59 requested_bytes=4528; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:314)` | 7 | 2112 |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 12 | 1484 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:295)` | 19 | 608 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:300)` | 18 | 228 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:320)` | 3 | 96 |
