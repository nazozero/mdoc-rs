# holder_es256_verify-allocations

# calls=5 requested_bytes=575; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 1 | 280 |
| `nazo_mdoc::cose::structure::authentication_structure (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/structure.rs:37)` | 1 | 142 |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 1 | 84 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:314)` | 1 | 64 |
| `nazo_mdoc::device_auth::verify_device_auth (/workspace/scratch/5e92231441b9/mdoc-rs/src/device_auth.rs:42)` | 1 | 5 |
