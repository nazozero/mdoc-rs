# response_parse-allocations

# calls=102 requested_bytes=12910; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 35 | 3824 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:218)` | 6 | 1842 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:295)` | 2 | 1508 |
| `nazo_mdoc::parser::parse_with_limits (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:54)` | 1 | 1064 |
| `nazo_mdoc::parser::parse_cose (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:295)` | 1 | 930 |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 3 | 840 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:147)` | 1 | 672 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:314)` | 5 | 576 |
| `<coset::header::Header as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:196)` | 1 | 256 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:133)` | 1 | 212 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:215)` | 6 | 192 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:320)` | 6 | 192 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:300)` | 16 | 158 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:145)` | 1 | 152 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:146)` | 1 | 152 |
| `nazo_mdoc::parser::parse_cose (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:304)` | 2 | 96 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:216)` | 6 | 73 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:306)` | 1 | 64 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:144)` | 1 | 56 |
| `nazo_mdoc::parser::parse_document (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:78)` | 1 | 21 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:151)` | 1 | 17 |
| `nazo_mdoc::parser::parse_cose (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:299)` | 2 | 6 |
| `nazo_mdoc::parser::parse_device_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:230)` | 1 | 4 |
| `nazo_mdoc::parser::parse_with_limits (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:39)` | 1 | 3 |
