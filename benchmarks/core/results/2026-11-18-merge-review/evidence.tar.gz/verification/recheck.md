## Targeted verification recheck — 2026-11-18

The final report's verification regression prompted a short recheck of the exact
retained executables. Baseline `b69ec61cb1f1c02a7c89d30c2d8e5bd1591addbd44fdc20a8c4cb222cd5fa218`
and candidate `d4eace027484d06a06cb97b8f28b992deb9e5f8137d2b96dcf378e0dfd870397`
match the original measurements. Source and dependencies were unchanged.

Each of three cases ran in separate processes on CPU 0, with 100 warmups and
1,000 observations. Four paired rounds used AB/BA/AB/BA order. Two subsequent
control rounds used the baseline executable for both labels. Timing and allocation
passes remained separate. All 36 processes succeeded, their input and deterministic
output hashes agreed, and all 36,000 observations are retained. The initial collector
read a wrong CSV field name after the first successful process; the collector was
corrected and resumed using that original process's recorded samples.

Values below are the median of the four per-round thread CPU quantiles, in microseconds.

| Operation | P50 baseline → candidate | Change | P95 baseline → candidate | P99 baseline → candidate |
| --- | ---: | ---: | ---: | ---: |
| Full protocol verification | 813.647 → 791.294 | −2.75% | 1,204.324 → 1,324.444 | 2,272.256 → 2,670.202 |
| Holder verification | 364.017 → 366.231 | +0.61% | 564.817 → 591.551 | 852.170 → 817.401 |
| External signing control | 345.134 → 327.503 | −5.11% | 526.810 → 490.386 | 749.723 → 714.325 |

Full verification's per-round P50 changes were +6.63%, −6.79%, −2.51% and +1.02%.
The earlier +7.32% aggregate increase therefore did not recur consistently. Holder
verification varied from −8.45% to +10.07%; its identical-binary control varied
from −7.01% to +3.55%. Full-verification P99 increased 17.51%, while its
identical-binary control increased 18.79%. These results establish substantial
variation in this shared host's timings. The original measurements remain in the
report; a deterministic source-level cause of their CPU regression remains unproven.

Allocation medians were identical in every process: full verification **155 → 121**
calls and **17,338 → 14,591** requested bytes; holder verification **15 → 5** calls
and **1,098 → 575** bytes. The signing control stayed at one allocation / 64 bytes.

Source review confirmed one issuer and one holder verification per presentation,
unchanged RustCrypto algorithms/features, and no added certificate parse or public-key
validation. The new code removes temporary allocations and repeated mutable-model
checks from private immutable paths. The evidence supports those reductions and
retains the variable CPU/tail results.
