import csv, hashlib, json, math, pathlib, statistics, subprocess, time
out = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('/workspace/scratch/5e92231441b9/mdoc-rs')
fixture = pathlib.Path('/workspace/scratch/5e92231441b9/core-fixture')
bins = {v:pathlib.Path(f'/workspace/scratch/5e92231441b9/target-core-{v}/release/mdoc-core-benchmark') for v in ['baseline','candidate']}
expected = {'baseline':'b69ec61cb1f1c02a7c89d30c2d8e5bd1591addbd44fdc20a8c4cb222cd5fa218','candidate':'d4eace027484d06a06cb97b8f28b992deb9e5f8137d2b96dcf378e0dfd870397'}
for label, p in bins.items():
 assert hashlib.sha256(p.read_bytes()).hexdigest() == expected[label]
cases = ['full_protocol_verify','holder_es256_verify','external_es256_sign_control']
runs=[]
summary=[]
for kind, rounds in [('comparison',4),('control',2)]:
 for round_num in range(1,rounds+1):
  order = ['baseline','candidate'] if round_num%2 else ['candidate','baseline']
  for case in cases:
   for position,label in enumerate(order):
    binary_label = label if kind=='comparison' else 'baseline'
    target=out/kind/f'round-{round_num:02d}'/case/label
    target.mkdir(parents=True)
    command=[str(bins[binary_label]),'--case',case,'--fixture',str(fixture),'--out',str(target),'--cpu','0','--samples','1000','--warmup','100']
    started=time.time()
    result=subprocess.run(command,cwd=repo,capture_output=True,text=True)
    (target/'execution.log').write_text(result.stdout+result.stderr)
    record={'kind':kind,'round':round_num,'case':case,'label':label,'binary_label':binary_label,'position':position,'sha256':expected[binary_label],'command':command,'started_unix':started,'elapsed_seconds':time.time()-started,'returncode':result.returncode}
    runs.append(record)
    (out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    if result.returncode: raise SystemExit(result.stderr)
    rows=list(csv.DictReader((target/'samples.csv').open()))
    assert len(rows)==1000 and all(row['case']==case for row in rows), (len(rows),rows[:1])
    values={key:sorted(int(row[key]) for row in rows) for key in ['cpu_ns','wall_ns','alloc_calls','requested_bytes']}
    entry={k:record[k] for k in ['kind','round','case','label','binary_label']}
    for key,data in values.items():
     for name, p in [('p50',.5),('p95',.95),('p99',.99)]:
      entry[f'{key}_{name}']=data[math.ceil(p*len(data))-1]
     entry[f'{key}_mean']=statistics.mean(data)
    summary.append(entry)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(kind, round_num, case, label, 'cpu P50',entry['cpu_ns_p50'],flush=True)
with (out/'summary.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
print('all runs completed',len(runs),flush=True)
