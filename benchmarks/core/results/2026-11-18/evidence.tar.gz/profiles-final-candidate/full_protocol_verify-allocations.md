# full_protocol_verify-allocations

# calls=128 requested_bytes=15468; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 31 | 3012 |
| `nazo_mdoc::verifier::verify_presentation (/workspace/scratch/5e92231441b9/mdoc-rs/src/verifier.rs:66)` | 1 | 1696 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:314)` | 11 | 1408 |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 5 | 1400 |
| `<x509_cert::name::RelativeDistinguishedName as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 4 | 1152 |
| `nazo_mdoc::parser::parse_with_limits (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:54)` | 1 | 1064 |
| `nazo_mdoc::cose::structure::authentication_structure (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/structure.rs:37)` | 2 | 567 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:295)` | 5 | 544 |
| `<nazo_mdoc::model::issuer_auth::IssuerAuth>::certificate_chain_der (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_auth.rs:63)` | 2 | 440 |
| `nazo_mdoc::parser::parse_cose (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:289)` | 1 | 391 |
| `<x509_cert::certificate::TbsCertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:117)` | 3 | 361 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_auth.rs:237)` | 1 | 308 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/rustc/0ef1bc386059596dada8fb65b50425aab2ea637a/library/alloc/src/collections/btree/set.rs:?)` | 1 | 280 |
| `<coset::header::Header as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:196)` | 1 | 256 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:276)` | 1 | 256 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:145)` | 2 | 229 |
| `nazo_mdoc::parser::parse_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:141)` | 1 | 224 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:300)` | 18 | 217 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:215)` | 2 | 217 |
| `<x509_cert::name::RdnSequence as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 2 | 192 |
| `<coset::key::CoseKeyBuilder>::new_ec2_pub_key (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:330)` | 1 | 192 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_auth.rs:244)` | 1 | 148 |
| `nazo_mdoc::parser::parse_cose (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:298)` | 2 | 128 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:202)` | 2 | 120 |
| `nazo_mdoc::session::build_device_authentication_validated (/workspace/scratch/5e92231441b9/mdoc-rs/src/session.rs:320)` | 1 | 108 |
| `nazo_mdoc::cbor::raw::project (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:320)` | 3 | 96 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:205)` | 1 | 84 |
| `<x509_cert::certificate::CertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::slice::SliceReader>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:195)` | 1 | 70 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:212)` | 2 | 64 |
| `<x509_cert::ext::Extension as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/ext.rs:27)` | 3 | 51 |
| `<x509_cert::serial_number::SerialNumber as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/serial_number.rs:82)` | 2 | 40 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/key.rs:196)` | 1 | 32 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/key.rs:197)` | 1 | 32 |
| `<x509_cert::attr::AttributeTypeAndValue as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/attr.rs:87)` | 4 | 28 |
| `nazo_mdoc::parser::parse_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:213)` | 2 | 22 |
| `nazo_mdoc::parser::parse_document (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:78)` | 1 | 21 |
| `nazo_mdoc::parser::parse_cose (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:293)` | 2 | 6 |
| `nazo_mdoc::device_auth::verify_device_signature (/workspace/scratch/5e92231441b9/mdoc-rs/src/device_auth.rs:61)` | 1 | 5 |
| `nazo_mdoc::parser::parse_device_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:227)` | 1 | 4 |
| `nazo_mdoc::parser::parse_with_limits (/workspace/scratch/5e92231441b9/mdoc-rs/src/parser.rs:39)` | 1 | 3 |
