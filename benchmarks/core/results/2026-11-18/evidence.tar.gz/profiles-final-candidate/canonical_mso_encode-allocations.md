# canonical_mso_encode-allocations

# calls=30 requested_bytes=6404; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::data_item::write_canonical (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/data_item.rs:64)` | 10 | 2880 |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 12 | 1484 |
| `nazo_mdoc::cbor::data_item::write_canonical (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/data_item.rs:?)` | 5 | 1392 |
| `nazo_mdoc::cbor::raw::push_head (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:397)` | 1 | 512 |
| `nazo_mdoc::cbor::raw::push_head (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:396)` | 2 | 136 |
