# issuer_signed_encode-allocations

# calls=45 requested_bytes=12421; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::encoder::push_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/encoder.rs:78)` | 1 | 3912 |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 31 | 3420 |
| `nazo_mdoc::cbor::raw::push_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:420)` | 2 | 1988 |
| `nazo_mdoc::cbor::raw::push_head (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:399)` | 1 | 978 |
| `nazo_mdoc::encoder::push_cose (/workspace/scratch/5e92231441b9/mdoc-rs/src/encoder.rs:34)` | 1 | 489 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:?)` | 1 | 472 |
| `<ciborium::value::Value as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:26)` | 1 | 466 |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 1 | 280 |
| `<coset::header::Header as coset::common::AsCborValue>::to_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:250)` | 1 | 256 |
| `<coset::header::Header as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:72)` | 1 | 64 |
| `nazo_mdoc::encoder::push_issuer_signed (/workspace/scratch/5e92231441b9/mdoc-rs/src/encoder.rs:59)` | 1 | 64 |
| `nazo_mdoc::cbor::raw::push_text (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:415)` | 1 | 16 |
| `nazo_mdoc::cbor::raw::push_head (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:396)` | 1 | 8 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:71)` | 1 | 8 |
