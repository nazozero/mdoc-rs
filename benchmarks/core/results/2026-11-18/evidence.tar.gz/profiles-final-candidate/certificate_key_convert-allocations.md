# certificate_key_convert-allocations

# calls=3 requested_bytes=256; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `<coset::key::CoseKeyBuilder>::new_ec2_pub_key (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:330)` | 1 | 192 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/key.rs:196)` | 1 | 32 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/key.rs:197)` | 1 | 32 |
