# issuance_complete-allocations

# calls=124 requested_bytes=14789; one successful operation; allocations only; no timing

| Call site | Calls | Requested bytes |
| --- | ---: | ---: |
| `nazo_mdoc::cbor::raw::scan (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:147)` | 20 | 2088 |
| `nazo_mdoc::cbor::data_item::write_canonical (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/data_item.rs:64)` | 7 | 1536 |
| `<x509_cert::name::RelativeDistinguishedName as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 4 | 1152 |
| `nazo_mdoc::cbor::data_item::write_canonical (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/data_item.rs:?)` | 5 | 880 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:361)` | 1 | 640 |
| `nazo_mdoc::cbor::raw::wrap_tag24_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:425)` | 3 | 628 |
| `unresolved` | 4 | 600 |
| `nazo_mdoc::cose::structure::authentication_structure (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/structure.rs:37)` | 1 | 425 |
| `<x509_cert::certificate::TbsCertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:117)` | 3 | 361 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:338)` | 1 | 320 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:166)` | 1 | 308 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_auth.rs:237)` | 1 | 308 |
| `<coset::common::Label as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/common/mod.rs:201)` | 1 | 280 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/rustc/0ef1bc386059596dada8fb65b50425aab2ea637a/library/alloc/src/collections/btree/set.rs:?)` | 1 | 280 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:78)` | 1 | 256 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::to_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:310)` | 1 | 256 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::from_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:276)` | 1 | 256 |
| `<coset::sign::CoseSign1Builder>::new (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/util/mod.rs:201)` | 1 | 256 |
| `<coset::header::Header as coset::common::AsCborValue>::to_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/header/mod.rs:213)` | 1 | 256 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:205)` | 1 | 224 |
| `nazo_mdoc::builder::encode_item (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:382)` | 2 | 214 |
| `nazo_mdoc::cbor::raw::push_text (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:415)` | 1 | 214 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:77)` | 1 | 212 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:165)` | 1 | 212 |
| `<coset::key::CoseKey as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:88)` | 1 | 192 |
| `<x509_cert::name::RdnSequence as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/macros.rs:56)` | 2 | 192 |
| `<coset::key::CoseKeyBuilder>::new_ec2_pub_key (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:330)` | 1 | 192 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:316)` | 1 | 192 |
| `nazo_mdoc::builder::fresh_item_randomness (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:409)` | 2 | 184 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:206)` | 1 | 148 |
| `nazo_mdoc::model::issuer_auth::parse_value_digests (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_auth.rs:244)` | 1 | 148 |
| `nazo_mdoc::cbor::raw::push_head (/workspace/scratch/5e92231441b9/mdoc-rs/src/cbor/raw.rs:396)` | 2 | 136 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:303)` | 1 | 128 |
| `<nazo_mdoc::time::Timestamp>::format_rfc3339 (/workspace/scratch/5e92231441b9/mdoc-rs/src/time.rs:94)` | 3 | 105 |
| `nazo_mdoc::builder::tdate (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:421)` | 3 | 96 |
| `<x509_cert::certificate::CertificateInner as der::decode::DecodeValue>::decode_value::<der::reader::slice::SliceReader>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/certificate.rs:195)` | 1 | 70 |
| `<ciborium::value::Value as core::clone::Clone>::clone (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:26)` | 2 | 64 |
| `nazo_mdoc::builder::fresh_item_randomness (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:410)` | 2 | 64 |
| `<nazo_mdoc::model::issuer_signed_item::IssuerSignedItem>::compute_digest (/workspace/scratch/5e92231441b9/mdoc-rs/src/model/issuer_signed_item.rs:32)` | 2 | 64 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:301)` | 1 | 64 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:363)` | 1 | 64 |
| `<coset::key::CoseKey as coset::common::AsCborValue>::to_cbor_value (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/coset-0.4.2/src/key/mod.rs:291)` | 1 | 64 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:197)` | 1 | 52 |
| `<x509_cert::ext::Extension as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/ext.rs:27)` | 3 | 51 |
| `<x509_cert::serial_number::SerialNumber as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/serial_number.rs:82)` | 2 | 40 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/key.rs:196)` | 1 | 32 |
| `nazo_mdoc::cose::key::cose_key_from_sec1_bytes (/workspace/scratch/5e92231441b9/mdoc-rs/src/cose/key.rs:197)` | 1 | 32 |
| `<x509_cert::attr::AttributeTypeAndValue as der::decode::DecodeValue>::decode_value::<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::nested::NestedReader<der::reader::slice::SliceReader>>>>>::{closure#0} (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/x509-cert-0.2.5/src/attr.rs:87)` | 4 | 28 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace::{closure#0} (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:81)` | 2 | 22 |
| `<nazo_mdoc::builder::DocumentBuilder>::new (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:60)` | 1 | 21 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:349)` | 1 | 21 |
| `<nazo_mdoc::builder::DocumentBuilder>::add_namespace (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:76)` | 1 | 17 |
| `<nazo_mdoc::builder::DocumentBuilder>::prepare (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:?)` | 1 | 17 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:344)` | 1 | 15 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:362)` | 1 | 13 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:352)` | 1 | 12 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:356)` | 1 | 12 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:326)` | 1 | 10 |
| `<ciborium::value::Value as core::convert::From<&str>>::from (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/mod.rs:605)` | 1 | 9 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:322)` | 1 | 9 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:364)` | 1 | 9 |
| `<ciborium::value::Value as serde_core::ser::Serialize>::serialize::<&mut ciborium::ser::Serializer<&mut alloc::vec::Vec<u8>>> (/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ciborium-0.2.2/src/value/ser.rs:71)` | 1 | 8 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:340)` | 1 | 7 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:345)` | 1 | 7 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:348)` | 1 | 7 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:318)` | 1 | 6 |
| `nazo_mdoc::builder::build_mso_cbor (/workspace/scratch/5e92231441b9/mdoc-rs/src/builder.rs:341)` | 1 | 3 |
